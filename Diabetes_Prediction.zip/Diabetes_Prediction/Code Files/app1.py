# -*- coding: utf-8 -*-
"""
Created on Mon Jul 11 15:57:37 2022

@author: Vedant Sunil Kulkarni
"""

import numpy as np
import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler
import sklearn
from PIL import Image

import streamlit as st

pickle_in=open("knn.pkl","rb")
knn=pickle.load(pickle_in)
scaler=pickle.load(open("scaler.pkl","rb"))

def welcome():
    return "Welcome All"


def predict_Diabetes(pregnancies,glucose,bloodpressure,skinthickness,insulin,bmi,DiabetesPedigreeFunction,age):
    
  
    prediction=knn.predict(scaler.transform([[pregnancies,glucose,bloodpressure,skinthickness,insulin,bmi,DiabetesPedigreeFunction,age]]))
    

    print(prediction)
    return prediction



def main():
    st.title("Diabetes Prediction Using Data Science")
    html_temp = """
    <div style="background-color:purple;padding:10px">
    <h2 style="color:white;text-align:center;">Diabetes Prediction App </h2>
    </div>
    """
    st.markdown(html_temp,unsafe_allow_html=True)
    pregnancies= st.text_input("Pregnancies","Enter the number of pregnancies")
    glucose= st.text_input("Glucose","Enter the value of glucose")
    bloodpressure = st.text_input("Blood Pressure","Enter the value of blood pressure")
    skinthickness = st.text_input("Skin Thickness","Enter the value of skin thickness (mm)")
    insulin = st.text_input("Insulin","Enter the value of insulin (mu U/ml)")
    bmi=st.text_input("BMI","Enter the value of BMI (weight in kg/(height in m)^2)")
    DiabetesPedigreeFunction=st.text_input("Diabetes pedigree function ","Enter the value of Diabetes pedigree function")
    age=st.text_input("Age","Enter your age")
    result=""
    if st.button("Predict"):
        result=predict_Diabetes(pregnancies,glucose,bloodpressure,skinthickness,insulin,bmi,DiabetesPedigreeFunction,age)
    #st.success('The output is {} '.format(result))
    if (result==1):
            st.success('Diabetes Positive ')
            image = Image.open(r"C:\Users\Vedant\OneDrive\Desktop\internship work\positiveimg.jpg")
            st.image(image, caption='Get Your sugar levels checked by doctor',width=None)
            st.success("Visit at this website to know more:- https://www.who.int/news-room/fact-sheets/detail/diabetes ")
            print("Diabetes positive")
    if (result==0):
            st.success('Diabetes negative')
            image1 = Image.open(r"C:\Users\Vedant\OneDrive\Desktop\internship work\negativeimg.jpg")
            st.image(image1, caption='You haveless chance of being diabetes positive',width=None)
            print("Diabetes negative")
    if st.button("About"):
        st.success("This Project is made by Vedant Kulkarni ,Student at PICT,Pune")
        st.success("Contact:- Linkedin:-www.linkedin.com/in/vedant-kulkarni-a32a83225")
            

if __name__=='__main__':
    main()